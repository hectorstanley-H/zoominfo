# tester-h — agent reference

A QA agent runner. You give it a URL and a natural-language test instruction;
it drives a real browser and reports `pass` / `fail`.

This file is the LLM-friendly cheatsheet. It describes everything you need to
drive the CLI non-interactively from another program.

---

## Install

```bash
npm install -g tester-h
# or run without installing
npx tester-h <args>
```

Requires Node 20+. The post-install hook fetches a Chromium binary via
Playwright. If it fails (proxy / restricted env), run:

```bash
npx playwright install chromium
```

## Authenticate (non-interactive)

Three options, in priority order:

```bash
# 1. Pass the key on every call
tester-h --api-key "sk-..." --url ... "<instruction>"

# 2. Environment variable
export HAI_API_KEY="sk-..."
tester-h --url ... "<instruction>"

# 3. Save once, reuse forever (recommended for local dev)
echo "$HAI_API_KEY" | tester-h login --json
# → {"saved":true,"masked_key":"sk-...","path":"<repo>/.env"}
```

`tester-h login` reads stdin when not on a TTY, so piping the key works
exactly as shown above. Keys are written as `HAI_API_KEY=…` to `<repo>/.env`
with mode `0600` (`.env` is in the default `.gitignore`). Use
`TESTER_H_PROJECT_ROOT` to relocate the project root (useful in
containers/CI).

## Pick an agent

There is no default agent. Every run must resolve an `agent_id` from one of
(in priority order):

```bash
# 1. Per-call flag
tester-h --agent-id <id> --url ... "<instruction>"

# 2. Project YAML (./.tester-h/tester-h.yaml)
agent_id: <id>

# 3. Saved with login
tester-h login --agent-id <id>
```

If none are set the CLI exits `1` with a `MissingAgentId` error (skipped
when `--local` is passed, since the local agent runs the loop in-process).

## First-time auto-save

The first time you pass `--api-key` or `--agent-id` on the CLI and the
corresponding slot isn't yet stored in `<repo>/.env`, the value is persisted
as your default. A one-line `Saved … as default in …` notice is printed
(suppressed under `--json`).

```bash
# Nothing stored yet:
tester-h --api-key "sk-..." --agent-id <id> --url ... "<instruction>"
# → Saved api key and agent id as default in <repo>/.env.

# Subsequent runs work with no flags:
tester-h --url ... "<instruction>"
```

Auto-save only triggers on **explicit CLI flags** — `HAI_API_KEY` and
`./.tester-h/tester-h.yaml` stay ephemeral. It also never overwrites a slot
that's already saved; to change defaults, run `tester-h login --force` (api
key) or `tester-h login --agent-id <id>` (agent id only).

## Bare invocation

`tester-h` with no arguments prints the help and exits `0` — no agent run,
no error. Use it as a quick sanity check after install.

## Browser presets and headed mode

`--device` picks a context preset; `--headed` shows the browser window
(default is headless). They compose:

```bash
tester-h --headed --device mobile --url ... "<instruction>"
```

| preset    | viewport    | UA                | scale | mobile | touch |
| --------- | ----------- | ----------------- | ----- | ------ | ----- |
| `mobile`  | 390 × 844   | iPhone 16-style   | 3     | yes    | yes   |
| `tablet`  | 1024 × 1366 | iPad 16-style     | 2     | yes    | yes   |
| `desktop` | 1920 × 1080 | (default Chromium) | 1    | no     | no    |

`--viewport WxH` overrides the preset's viewport size while keeping the
rest of the descriptor (UA, scale, isMobile, hasTouch). Both flags are
also settable in `.tester-h/tester-h.yaml`:

```yaml
device: mobile
headed: true
```

## Subcommands

```
tester-h [run] [options] "<instruction>"   # default — run an agent
tester-h login   [--api-key K] [--json]    # stdin if no flag
tester-h logout  [--json]
tester-h whoami  [--json]
tester-h init    [--json]                  # writes ./.tester-h/tester-h.yaml
tester-h help
tester-h version
```

## All flags

| Flag                    | Meaning                                          |
| ----------------------- | ------------------------------------------------ |
| `--url <url>`           | URL to test (default `http://localhost:3000`)    |
| `--api-key <key>`       | Override the saved key                           |
| `--agent-id <id>`       | Pick the agent (required; no default)            |
| `--config <path>`       | Project YAML (default `./.tester-h/tester-h.yaml`) |
| `--timeout <s>`         | Run timeout, seconds (default `600`)             |
| `--viewport <WxH>`      | Viewport (default `1920x1080`)                   |
| `--device <name>`       | Preset: `mobile` \| `tablet` \| `desktop`        |
| `--headed`              | Show the browser window (default: headless)      |
| `--config-override <s>` | Per-run agent override (YAML or `@file`)         |
| `--inference`           | Skip the agent loop, query the model directly    |
| `--model <name>`        | Model for `--inference`                          |
| `--system-prompt <s>`   | System prompt for `--inference` (or `@file`)     |
| `--json`                | NDJSON output on stdout                          |
| `--debug`               | Include agent-message and poll-error events      |
| `--help, -h`            |                                                  |
| `--version, -v`         |                                                  |

The instruction is the **last positional argument**. Quote it.

## Exit codes

| Code | Meaning                                         |
| ---- | ----------------------------------------------- |
| `0`  | `pass`                                          |
| `1`  | `fail`, unknown verdict, timeout, or run error  |

## NDJSON event stream (`--json`)

When `--json` is set, the CLI writes one JSON object per line on stdout and
suppresses every human-formatted line. Stderr is unused. Every event has a
`type` and an `at_ms` (ms since process start).

### `run` events

| `type`            | Fields                                                                                | When                                              |
| ----------------- | ------------------------------------------------------------------------------------- | ------------------------------------------------- |
| `start`           | `url`, `task`, `viewport`, `timeout`                                                  | First event                                       |
| `trajectory`      | `id`                                                                                  | After the agent session is created                |
| `action`          | `index` (1-based), `name`, `detail` (string \| null)                                  | Every browser action the agent issues             |
| `command_error`   | `name`, `message`                                                                     | A browser command raised an error                 |
| `agent_message`   | `text`                                                                                | Only with `--debug`: the agent's narration        |
| `poll_error`      | `message`                                                                             | Only with `--debug`: transient API hiccups        |
| `warn`            | `message`                                                                             | Soft issues (interrupted, timeout)                |
| `error`           | `message`, optional `hint`                                                            | Run-fatal error (no `end` will follow)            |
| `end`             | `verdict`, `summary`, `answer`, `actions`, `elapsed_ms`, `status`, `trajectory`       | Last event on a successful run                    |

`verdict` is `"pass" \| "fail" \| "unknown"`. The exit code is `0` iff
`verdict === "pass"`.

### Example session

```
$ tester-h --json --url https://example.com "Click sign up; assert the form rejects an empty email"
{"type":"start","url":"https://example.com","task":"Click sign up; assert the form rejects an empty email","viewport":"1920x1080","timeout":600,"at_ms":0}
{"type":"trajectory","id":"6f5e0d…","at_ms":812}
{"type":"action","index":1,"name":"navigate","detail":"https://example.com","at_ms":1100}
{"type":"action","index":2,"name":"click","detail":"Sign up","at_ms":2400}
{"type":"action","index":3,"name":"click","detail":"Submit","at_ms":3000}
{"type":"end","verdict":"pass","summary":"Empty email is rejected","answer":"…full agent reply…","actions":3,"elapsed_ms":4200,"status":"completed","trajectory":"6f5e0d…","at_ms":4205}
```

Consume with:

```bash
tester-h --json --url ... "..." | jq -c 'select(.type=="end")'
```

### `login` / `logout` / `whoami` / `init` JSON shapes

Single-line objects, not NDJSON:

```jsonc
// whoami (logged out)
{"logged_in":false}
// whoami (file)
{"logged_in":true,"source":"file","masked_key":"sk-l…cdef","path":"/path/to/repo/.env","agent_id":null}
// whoami (env)
{"logged_in":true,"source":"env","masked_key":"sk-l…cdef"}
// login (success)
{"saved":true,"masked_key":"sk-l…cdef","path":"…"}
// login (already logged in, no --force)
{"saved":false,"reason":"already_logged_in","masked_key":"…","path":"…"}
// login (cancelled / empty)
{"saved":false,"error":"cancelled"}
{"saved":false,"error":"no_key_provided"}
// logout
{"removed":true,"path":"…"}      // or "removed":false
// init
{"created":true,"path":"/path/to/repo/.tester-h/tester-h.yaml","project_dir":"/path/to/repo/.tester-h"}
{"created":false,"reason":"exists","path":"/path/to/repo/.tester-h/tester-h.yaml","project_dir":"/path/to/repo/.tester-h"}
```

## Recipes

### One-shot test, get the verdict

```bash
RESULT=$(tester-h --json --url https://app.example.com \
  "On /games, the primary button must be black" \
  | tail -1)
echo "$RESULT" | jq -r '.verdict'   # pass | fail | unknown
echo "$RESULT" | jq -r '.summary'
```

### Stream actions live and react to them

```bash
tester-h --json --url ... "..." | while read -r line; do
  type=$(echo "$line" | jq -r .type)
  case "$type" in
    action) echo "→ $(echo "$line" | jq -r '"\(.name) \(.detail // "")"')" ;;
    end)    echo "$line" | jq -r '"\(.verdict) (\(.actions) actions)"' ;;
    error)  echo "ERR: $(echo "$line" | jq -r .message)" ;;
  esac
done
```

### Inference mode (one screenshot, one model call)

```bash
tester-h --inference --url https://example.com \
  --model holo3-35b-a3b \
  "What is the headline?"
```

## Constraints to keep in mind

- The agent ends its reply with a JSON block that contains `"verdict"`. If it
  doesn't (timeout, crash, unclear answer), `verdict` is `"unknown"` and the
  exit code is `1`.
- `--json` writes only to stdout. Mix with `2>/dev/null` if you want to be
  paranoid about stray output — there should be none, but Node may print
  unhandled-rejection traces on stderr in pathological cases.
- Output is line-buffered. One `\n`-terminated JSON object per line.
- `Ctrl-C` (SIGINT/SIGTERM) cancels cleanly: emits a `warn` event, then
  exits `1`.
- The instruction is sent verbatim to the agent inside a small system
  wrapper that asks it to end with the verdict block. Phrase the instruction
  as a test: "verify X", "check that Y", "click Z and confirm W".
