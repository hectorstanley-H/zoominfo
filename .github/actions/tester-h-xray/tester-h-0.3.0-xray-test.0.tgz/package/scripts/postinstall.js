#!/usr/bin/env node
// Fetches a Chromium binary for playwright-core after install.
// Skips automatically when npm is doing a lockfile-only or dry-run pass —
// otherwise `npm install --package-lock-only` would block on a multi-hundred-MB
// download nobody asked for.

import { execSync } from 'node:child_process';

const isLockOnly = process.env.npm_config_package_lock_only === 'true';
const isDryRun = process.env.npm_config_dry_run === 'true';
const skipEnv = process.env.TESTER_H_SKIP_POSTINSTALL === '1';

if (isLockOnly || isDryRun || skipEnv) {
  const reason = isLockOnly
    ? '--package-lock-only'
    : isDryRun
      ? '--dry-run'
      : 'TESTER_H_SKIP_POSTINSTALL=1';
  console.log(
    `[tester-h] Skipping Chromium install (${reason}). ` +
      'Run `npx playwright install chromium` when you actually need the browser.',
  );
  process.exit(0);
}

try {
  execSync('npx --yes playwright install chromium', { stdio: 'inherit' });
} catch {
  console.log(
    '\n[tester-h] Could not auto-install Chromium. ' +
      'Run `npx playwright install chromium` manually.',
  );
}
